import nltk
nltk.download('punkt')